# ZeRO: Zero-Knowledge Risk Oracle" 
